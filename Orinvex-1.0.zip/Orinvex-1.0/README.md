# Orinvex 1.0

Orinvex is a small scripting language with an interpreter written in Python.
Programs are plain text files with the `.ovx` extension.

```
import rest

define.name = "world".end
print.ConsoleText("Hello, world!")end

loop -- <true>.Repeat(3)
    print.ConsoleText("Tick")end
    rest.wait -- milliseconds(500)end
end
```

## Requirements

- Python 3.8 or newer
- Linux or macOS (for `install.sh`); the interpreter itself runs anywhere Python does

## Quick start

Run a program without installing:

```bash
python3 orinvex.py examples/hello.ovx
```

Install the `orinvex` command:

```bash
chmod +x install.sh uninstall.sh
./install.sh
orinvex examples/hello.ovx
```

Uninstall:

```bash
./uninstall.sh
```

## What Orinvex 1.0 supports

| Feature | Syntax |
|---|---|
| Comments | `# comment` (own line) |
| Variables | `define.x = 5.end` and `data:Get.x` |
| Console output | `print.ConsoleText(...)end` |
| Number output | `print.Number(...)end` |
| Waiting | `import rest`, then `rest.wait -- time(1)end` |
| Loops | `loop -- <true>.Repeat(5)` ... `end` |
| Several commands per line | `cmd1 - cmd2 - cmd3` |

Not implemented yet: user input, if/else conditions, functions and math
expressions. The matching files in `examples/` are placeholders that
describe this.

## Project layout

```
Orinvex-1.0/
├── orinvex.py      interpreter
├── install.sh      installs the `orinvex` command
├── uninstall.sh    removes it
├── examples/       example programs (.ovx)
└── docs/           syntax, command reference, installation guide
```

## Documentation

- [docs/syntax.md](docs/syntax.md): how the language is written
- [docs/commands.md](docs/commands.md): every command in detail
- [docs/installation.md](docs/installation.md): installing and troubleshooting

## License

MIT, see [LICENSE](LICENSE).
